## Code samples

Not sure what to provide here, so below is a link to my github for code samples, thanks!
https://github.com/soghammed

